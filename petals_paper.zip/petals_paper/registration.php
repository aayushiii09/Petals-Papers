<?php
session_start();
include("connection.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = $_POST['name'];
    $email    = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // secure hash
    $role     = $_POST['role']; // selected role (user/admin)

    // Check if email already exists
    $check = $conn->prepare("SELECT id FROM users WHERE email=?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $message = "⚠️ Email already registered!";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)");
        $stmt->bind_param("ssss", $name, $email, $password, $role);
        if ($stmt->execute()) {
            $message = "✅ Registration successful! Please login.";
        } else {
            $message = "❌ Error: " . $conn->error;
        }
        $stmt->close();
    }
    $check->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register - Petals & Paper</title>
</head>
<body>
    <h2>User Registration</h2>
    <form method="post" action="">
        <label>Name:</label><br>
        <input type="text" name="name" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>

        <label>Register As:</label><br>
        <input type="radio" name="role" value="user" required> User  
        <input type="radio" name="role" value="admin" required> Admin  
        <br><br>

        <button type="submit">Register</button>
    </form>
    <p style="color:red;"><?php echo $message; ?></p>
    <p>Already have an account? <a href="login.php">Login here</a></p>
</body>
</html>
