<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>About Us - Petals & Paper</title>
<link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Playfair+Display:wght@400;700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
<style>
body { font-family:'Lato', sans-serif; background:#fff0f5; margin:0; color:#333; }
header {
    background: linear-gradient(135deg, #ffb6c1, #ff69b4);
    padding:20px 50px; display:flex; justify-content:space-between; align-items:center;
    position:sticky; top:0; z-index:1000; box-shadow:0 5px 15px rgba(0,0,0,0.1);
}
header h1 { font-family:'Pacifico', cursive; font-size:2.5em; color:white; }
nav a { color:white; text-decoration:none; margin-left:25px; font-weight:bold; transition:0.3s; }
nav a:hover { text-decoration:underline; }

.section {
    padding:80px 50px; text-align:center;
}
.section h2 { font-family:'Playfair Display', serif; font-size:2.5em; color:#ff1493; margin-bottom:20px; }
.section p { font-size:1.2em; line-height:1.8; color:#333; max-width:900px; margin:0 auto; }

footer { text-align:center; padding:25px; background:#ffb6c1; color:white; font-weight:bold; }
</style>
</head>
<body>

<header>
    <h1>🌸 Petals & Paper</h1>
    <nav>
        <a href="index.php">Home</a>
        <a href="user/user_dashboard.php">Shop</a>
        <a href="contact.php">Contact</a>
        <?php if(isset($_SESSION['id']) && $_SESSION['role']=="user"){ ?>
            <a href="logout.php">Logout</a>
        <?php } else { ?>
            <a href="login.php">Login</a>
            <a href="registration.php">Register</a>
        <?php } ?>
    </nav>
</header>

<section class="section">
    <h2>About Petals & Paper</h2>
    <p>Welcome to <strong>Petals & Paper</strong>! We are passionate about curating a unique collection of aesthetic stationery and self-care products that inspire creativity, mindfulness, and elegance. 🌷</p>
    <p>Our mission is to make your everyday routine delightful and beautiful. From luxurious candles and diffusers to thoughtfully crafted notebooks and pens, every product is handpicked to bring joy and elegance into your life. 💖</p>
    <p>We believe in quality, beauty, and a touch of floral magic in every item. Thank you for visiting our store and joining our journey to spread joy, creativity, and aesthetic bliss! ✨</p>
</section>

<footer>
    &copy; <?php echo date("Y"); ?> Petals & Paper | All Rights Reserved
</footer>

</body>
</html>
