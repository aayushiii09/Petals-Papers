<?php
session_start();

// Destroy all sessions
session_unset();
session_destroy();

// Redirect everyone (user or admin) to homepage
header("Location: index.php");
exit;
?>
