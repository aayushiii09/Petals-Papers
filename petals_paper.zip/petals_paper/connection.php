<?php
$host = "localhost";   // host
$user = "root";        // username (default = root)
$pass = "";            // password (default empty for XAMPP)
$db   = "petals_paper"; // database name

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
