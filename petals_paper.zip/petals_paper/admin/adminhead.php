<?php
session_start();
include '../connection.php';

//Only Admin can access
if (!isset($_SESSION['email']) || $_SESSION['type'] !== "Admin") {
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel</title>
<link rel="stylesheet" href="../style.css">
<style>
/* Admin Header & Navbar Styling */
body {
    font-family: 'Poppins', sans-serif;
    background: #fff0f6;
    margin: 0;
    padding: 0;
}
header {
    background: #e91e63;
    color: #fff;
    padding: 20px;
    text-align: center;
    font-size: 28px;
    font-weight: bold;
}
.navbar {
    display: flex;
    justify-content: center;
    background: #ff66a3;
    padding: 15px 0;
    gap: 30px;
    flex-wrap: wrap;
}
.navbar a {
    color: #fff;
    text-decoration: none;
    font-weight: bold;
    padding: 8px 15px;
    border-radius: 20px;
    transition: 0.3s;
}
.navbar a:hover {
    background: #fff;
    color: #e91e63;
}
.logout {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #e91e63;
    color: #fff;
    padding: 10px 20px;
    border-radius: 30px;
    text-decoration: none;
    transition: 0.3s;
}
.logout:hover {
    background: #ff6090;
}
</style>
</head>
<body>

<header>Admin Dashboard</header>

<div class="navbar">
    <a href="adminhome.php">Home</a>
    <a href="addproducts.php">Add Products</a>
    <a href="viewproducts.php">View Products</a>
    <a href="viewusers.php">View Users</a>
</div>

<a href="../logout.php" class="logout">Logout</a>