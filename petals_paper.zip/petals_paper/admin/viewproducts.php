<?php
session_start();
include("../connection.php");

// Only admin can access
if(!isset($_SESSION['id']) || $_SESSION['role'] !== "admin"){
    header("Location: ../login.php");
    exit;
}

// Delete product
if(isset($_GET['delete'])){
    $id = intval($_GET['delete']);
    // Option: delete image from server
    $result = $conn->query("SELECT image FROM products WHERE id=$id");
    if($row = $result->fetch_assoc()){
        if(!empty($row['image']) && file_exists("../images/".$row['image'])){
            unlink("../images/".$row['image']);
        }
    }
    $conn->query("DELETE FROM products WHERE id=$id");
    header("Location: viewproducts.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Products - Admin</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
<header>
    <h1>View Products</h1>
    <p><a href="admin_dashboard.php">⬅ Back to Dashboard</a> | <a href="../logout.php">Logout</a></p>
</header>

<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Price (₹)</th>
        <th>Image</th>
        <th>Action</th>
    </tr>
    <?php
    $sql = "SELECT * FROM products ORDER BY id DESC";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            echo "<tr>";
            echo "<td>".$row['id']."</td>";
            echo "<td>".$row['name']."</td>";
            echo "<td>₹".$row['price']."</td>";
            echo "<td><img src='../images/".$row['image']."' width='80'></td>";
            echo "<td><a href='viewproducts.php?delete=".$row['id']."' onclick='return confirm(\"Are you sure?\")'>Delete</a></td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No products added yet!</td></tr>";
    }
    ?>
</table>
</body>
</html>
