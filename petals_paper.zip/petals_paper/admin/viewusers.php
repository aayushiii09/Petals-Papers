<?php
session_start();
include("../connection.php");

// Only admin can access
if(!isset($_SESSION['id']) || $_SESSION['role'] != "admin"){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Users - Admin</title>
<link rel="stylesheet" href="adminstyle.css">
<style>
table {
    width: 90%;
    margin: 20px auto;
    border-collapse: collapse;
}
th, td {
    padding: 10px;
    border: 1px solid #ccc;
    text-align: center;
}
th {
    background: #ffb6c1;
    color: white;
}
tr:nth-child(even) {
    background: #f9f9f9;
}
</style>
</head>
<body>
<h2 style="text-align:center;">👤 Registered Users</h2>

<table>
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Role</th>
</tr>

<?php
$sql = "SELECT id, name, email, role FROM users";
$result = $conn->query($sql);

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        echo "<tr>";
        echo "<td>".$row['id']."</td>";
        echo "<td>".$row['name']."</td>";
        echo "<td>".$row['email']."</td>";
        echo "<td>".$row['role']."</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>No users found!</td></tr>";
}
?>
</table>
</body>
</html>
