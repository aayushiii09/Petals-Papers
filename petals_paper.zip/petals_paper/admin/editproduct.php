<?php
include 'adminhead.php';

if(isset($_GET['id'])){
    $id = intval($_GET['id']);
    $query = "SELECT * FROM products WHERE id=$id";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
}

if(isset($_POST['update'])){
    $name = $_POST['name'];
    $price = $_POST['price'];

    // Image handling
    if(!empty($_FILES['image']['name'])){
        $image = $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];
        move_uploaded_file($tmp, "../images/$image");
        $query = "UPDATE products SET name='$name', price='$price', image='$image' WHERE id=$id";
    } else {
        $query = "UPDATE products SET name='$name', price='$price' WHERE id=$id";
    }

    mysqli_query($conn, $query);
    header("Location: viewproducts.php");
}
?>

<div class="container">
    <h2 style="text-align:center; color:#e91e63;">Edit Product</h2>
    <form method="post" enctype="multipart/form-data" class="product-form">
        <label>Product Name:</label>
        <input type="text" name="name" value="<?php echo $row['name']; ?>" required>
        <label>Price (₹):</label>
        <input type="number" name="price" value="<?php echo $row['price']; ?>" required>
        <label>Image:</label>
        <input type="file" name="image">
        <img src="../images/<?php echo $row['image']; ?>" style="width:100px; border-radius:10px; margin:10px 0;">
        <input type="submit" name="update" value="Update Product">
    </form>
</div>

<style>
.container { width: 50%; margin:auto; background:#fff0f6; padding:20px; border-radius:15px; margin-top:30px; }
.product-form { display:flex; flex-direction:column; }
.product-form label { margin:10px 0 5px; font-weight:bold; }
.product-form input[type="text"], .product-form input[type="number"], .product-form input[type="file"] {
    padding:8px; border-radius:10px; border:1px solid #e91e63;
}
.product-form input[type="submit"] {
    margin-top:20px; padding:10px; background:#e91e63; color:white; border:none; border-radius:20px; cursor:pointer;
    font-weight:bold; transition:0.3s;
}
.product-form input[type="submit"]:hover { background:#d81b60; }
</style>
