<?php
include 'adminhead.php';

if(isset($_GET['id'])){
    $id = intval($_GET['id']);
    $query = "DELETE FROM products WHERE id=$id";
    mysqli_query($conn, $query);
}

header("Location: viewproducts.php");
exit;
?>
