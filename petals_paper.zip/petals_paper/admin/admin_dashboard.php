<?php
session_start();
include("../connection.php");

// Only admin can access
if(!isset($_SESSION['id']) || $_SESSION['role'] !== "admin"){
    header("Location: ../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Petals & Paper</title>
    <style>
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #ffe6f0, #fff0f5, #ffe4e1);
            color: #333;
        }

        /* Header */
        header {
            background: linear-gradient(90deg, #ff69b4, #ff9ecd);
            color: #fff;
            padding: 20px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        header h1 {
            font-size: 26px;
            font-weight: bold;
        }

        header p {
            font-size: 16px;
        }

        header a {
            color: #fff;
            margin-left: 15px;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        header a:hover {
            text-decoration: underline;
            color: #ffe6f0;
        }

        /* Dashboard Container */
        main {
            padding: 50px;
            display: flex;
            justify-content: center;
        }

        .admin-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 30px;
            width: 100%;
            max-width: 1000px;
        }

        .admin-options a {
            background: #fff;
            padding: 40px 20px;
            text-align: center;
            border-radius: 20px;
            text-decoration: none;
            color: #ff69b4;
            font-size: 18px;
            font-weight: bold;
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
            transition: all 0.3s;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .admin-options a:hover {
            transform: translateY(-6px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            background: linear-gradient(135deg, #ffebf5, #ffe6f0);
        }

        .admin-options a span {
            font-size: 40px;
            margin-bottom: 15px;
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 20px;
            background: linear-gradient(90deg, #ff9ecd, #ff69b4);
            color: #fff;
            margin-top: 40px;
            font-size: 14px;
        }
    </style>
</head>
<body>

<header>
    <h1>🌸 Admin Dashboard</h1>
    <p>Welcome, <?php echo $_SESSION['name']; ?> 
       <a href="../logout.php">Logout</a>
    </p>
</header>

<main>
    <div class="admin-options">
        <a href="addproducts.php"><span>➕</span> Add Products</a>
        <a href="viewproducts.php"><span>📦</span> View Products</a>
        <a href="viewusers.php"><span>👤</span> View Users</a>
        <a href="vieworders.php"><span>🛒</span> View Orders</a>
    </div>
</main>

<footer>
    &copy; <?php echo date("Y"); ?> Petals & Paper | Admin Panel 🌷
</footer>

</body>
</html>
