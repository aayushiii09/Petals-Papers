<?php 
session_start();
include("../connection.php");

// Only admin can access
if(!isset($_SESSION['id']) || $_SESSION['role'] != "admin"){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Orders - Admin</title>
<link rel="stylesheet" href="adminstyle.css">
<style>
body {
    font-family: 'Poppins', sans-serif;
}
.top-bar {
    width: 95%;
    margin: 20px auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.top-bar a {
    text-decoration: none;
    margin-left: 15px;
    padding: 8px 16px;
    border-radius: 20px;
    background: linear-gradient(90deg, #ff69b4, #ff9ecd);
    color: white;
    font-weight: 500;
    transition: 0.3s;
}
.top-bar a:hover {
    background: linear-gradient(90deg, #ff4081, #ff77a9);
}
table {
    width: 95%;
    margin: 20px auto;
    border-collapse: collapse;
}
th, td {
    padding: 10px;
    border: 1px solid #ccc;
    text-align: center;
}
th {
    background: #ff69b4;
    color: white;
}
tr:nth-child(even) {
    background: #f9f9f9;
}
</style>
</head>
<body>

<div class="top-bar">
    <h2>🛒 Orders</h2>
    <div>
        <a href="admin_dashboard.php">⬅️ Back to Dashboard</a>
        <a href="../logout.php">🚪 Logout</a>
    </div>
</div>

<table>
<tr>
    <th>Order ID</th>
    <th>User ID</th>
    <th>Product IDs</th>
    <th>Total Amount</th>
    <th>Order Date</th>
</tr>

<?php
$sql = "SELECT * FROM orders ORDER BY id DESC";
$result = $conn->query($sql);

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        echo "<tr>";
        echo "<td>".$row['id']."</td>";
        echo "<td>".$row['user_id']."</td>";
        echo "<td>".$row['product_ids']."</td>";
        echo "<td>₹".$row['total_amount']."</td>";
        echo "<td>".$row['order_date']."</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='5'>No orders found!</td></tr>";
}
?>
</table>

</body>
</html>
