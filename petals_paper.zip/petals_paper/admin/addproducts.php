<?php
session_start();
include("../connection.php");

// Only admin can access
if(!isset($_SESSION['id']) || $_SESSION['role'] !== "admin"){
    header("Location: ../login.php");
    exit;
}

$message = "";

if(isset($_POST['submit'])){
    $name  = $_POST['name'];
    $price = $_POST['price'];
    
    // Handle image upload
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0){
        $filename = time().'_'.$_FILES['image']['name'];
        $target = "../images/".$filename;
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    } else {
        $filename = null;
    }

    $stmt = $conn->prepare("INSERT INTO products (name, price, image) VALUES (?, ?, ?)");
    $stmt->bind_param("sds", $name, $price, $filename);

    if($stmt->execute()){
        $message = "✅ Product added successfully!";
    } else {
        $message = "❌ Failed to add product!";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Product - Admin</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
<header>
    <h1>Add Product</h1>
    <p><a href="admin_dashboard.php">⬅ Back to Dashboard</a> | <a href="../logout.php">Logout</a></p>
</header>

<div class="form-container">
    <form method="post" enctype="multipart/form-data">
        <label>Product Name:</label><br>
        <input type="text" name="name" required><br><br>

        <label>Price (₹):</label><br>
        <input type="number" name="price" step="0.01" required><br><br>

        <label>Product Image:</label><br>
        <input type="file" name="image" accept="image/*"><br><br>

        <button type="submit" name="submit">Add Product</button>
    </form>
    <p style="color:green;"><?php echo $message; ?></p>
</div>
</body>
</html>
