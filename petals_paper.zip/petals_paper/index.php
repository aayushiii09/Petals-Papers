<?php 
session_start();
include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>🌸 Petals & Paper</title>
<style>
/* Reset */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}

.logo {
  display: flex;
  flex-direction: column;
}

.logo h1 {
  margin-bottom: 5px;
}

.tagline {
  font-size: 14px;
  font-style: italic;
  color: #ffe6f0;
}

/* Body with soft gradient */
body {
  background: linear-gradient(135deg, #ffe6f0, #fff0f5, #ffe4e1);
  color: #333;
}

/* Header / Nav Bar */
header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 18px 50px;
  background: linear-gradient(90deg, #ff69b4, #ff9ecd);
  color: #fff;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

header h1 {
  font-size: 26px;
  font-weight: bold;
}

nav a {
  margin: 0 14px;
  text-decoration: none;
  color: #fff;
  font-weight: 500;
  transition: all 0.3s;
}

nav a:hover {
  color: #ffe6f0;
  text-decoration: underline;
}

/* Hero Section */
.hero {
  position: relative;
  height: 75vh;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  overflow: hidden;
  color: #fff;
}

/* Slideshow images stacked */
.slideshow {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}

.slideshow img {
  position: absolute;
  top: 0; left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0;
  transition: opacity 1s ease-in-out;
}

.slideshow img.active {
  opacity: 1;
}

/* Hero text */
.hero-content {
  z-index: 2;
  background: rgba(255, 105, 180, 0.7);
  padding: 30px 60px;
  border-radius: 20px;
  box-shadow: 0 6px 20px rgba(0,0,0,0.25);
  max-width: 600px;
}

.hero-content h2 {
  font-size: 38px;
  margin-bottom: 12px;
}

.hero-content p {
  font-size: 18px;
  margin-bottom: 20px;
}

.shop-btn {
  display: inline-block;
  padding: 12px 30px;
  background: #fff;
  color: #ff69b4;
  border-radius: 40px;
  font-weight: bold;
  text-decoration: none;
  transition: all 0.3s;
}

.shop-btn:hover {
  background: #ff69b4;
  color: #fff;
}

/* Products Grid */
.products-container {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 25px;
  padding: 60px;
}

.card {
  background: #fff;
  border-radius: 18px;
  padding: 20px;
  text-align: center;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.card:hover {
  transform: translateY(-6px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.15);
}

.card img {
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 14px;
  margin-bottom: 15px;
}

.card h2 {
  font-size: 18px;
  color: #333;
  margin-bottom: 8px;
}

.card p {
  font-size: 16px;
  font-weight: bold;
  color: #ff69b4;
  margin-bottom: 10px;
}

.card input[type="number"] {
  width: 60px;
  padding: 5px;
  margin-bottom: 10px;
  border: 1px solid #ddd;
  border-radius: 6px;
}

.card button {
  background: linear-gradient(90deg, #ff69b4, #ff9ecd);
  border: none;
  padding: 8px 15px;
  color: #fff;
  border-radius: 20px;
  cursor: pointer;
  transition: background 0.3s;
}

.card button:hover {
  background: linear-gradient(90deg, #ff4081, #ff77a9);
}

/* Footer */
footer {
  text-align: center;
  padding: 20px;
  background: linear-gradient(90deg, #ff9ecd, #ff69b4);
  color: #fff;
  margin-top: 50px;
  font-size: 14px;
}

.see-more {
  text-align: center;
  margin: 30px auto 60px;
  padding: 25px;
  max-width: 700px;
  background: linear-gradient(135deg, #fff0f5, #ffe4e1, #fffafc);
  border-radius: 20px;
  font-size: 18px;
  font-style: italic;
  color: #555;
  line-height: 1.6;
  box-shadow: 0 4px 15px rgba(255,182,193,0.3);
}

.see-more a {
  color: #ff69b4;
  font-weight: bold;
  text-decoration: none;
  transition: all 0.3s ease;
}

.see-more a:hover {
  color: #ff1493;
  text-decoration: underline;
}

</style>
</head>
<body>

<header>
    <div class="logo">
        <h1>🌸 Petals & Paper</h1>
        <p class="tagline"><b>Pretty Picks for Every Mood 🌸🎀✨</b></p>
    </div>
    <nav>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="contact.php">Contact</a>
    
    <?php if(isset($_SESSION['id']) && $_SESSION['role']=="user"){ ?>
        <a href="user/user_dashboard.php">Shop</a>
        <a href="logout.php">Logout</a>
    
    <?php } elseif(isset($_SESSION['id']) && $_SESSION['role']=="admin"){ ?>
        <a href="admin/admin_dashboard.php">Admin Dashboard</a>
        <a href="logout.php">Logout</a>
    
    <?php } else { ?>
        <!-- No Login/Register here anymore since shown in message box -->
    <?php } ?>
</nav>
</header>

<!-- Hero Section -->
<section class="hero">
  <div class="slideshow">
      <img src="images/ig1.jpg" class="active" alt="Gift 1">
      <img src="images/ig2.jpg" alt="Gift 2">
      <img src="images/ig3.jpg" alt="Gift 3">
  </div>
  <div class="hero-content">
      <h3>✨ Curated Gifts for Your Soul 🌸</h3>
      <p>Stationery & Self-Care Treasures Wrapped with Love</p>
      <a href="user/user_dashboard.php" class="shop-btn">Shop Now</a>
  </div>
</section>


<!-- Products Section -->
<div class="products-container">
<?php
$sql = "SELECT id, name, price, image FROM products LIMIT 10";
$result = $conn->query($sql);

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        $img = !empty($row['image']) ? $row['image'] : 'default.jpg';
        echo '<div class="card">';
        echo '<img src="images/'.$img.'" alt="product">';
        echo '<h2>'.$row['name'].'</h2>';
        echo '<p>₹'.$row['price'].'</p>';
        echo '<form method="post" action="user/user_dashboard.php">';
        echo '<input type="hidden" name="product_id" value="'.$row['id'].'">';
        echo '<input type="number" name="quantity" value="1" min="1">';
        echo '<button type="submit" name="add_to_cart">Add to Cart</button>';
        echo '</form>';
        echo '</div>';
    }
} else {
    echo "<p class='no-products'>No products available!</p>";
}
?>
</div>

<!-- Login/Register Reminder -->
<div class="see-more">
  <p>🌷 Every garden hides blossoms you can’t see at first glance…  
  🌸 Step inside by logging in or registering,  
  and let Petals & Paper show you all its hidden beauty 💖</p>
  <p><a href="login.php">Login</a> | <a href="registration.php">Register</a></p>
</div>

<!-- Footer -->
<footer>
	<p class="aesthetic-para">
    💖 Because beauty lives in the little things —  
    a handwritten note, a bouquet on your desk,  
    a soft journal page waiting for your story.  
    <br>
    🌸 Petals & Paper is here to remind you:  
    every day deserves a touch of magic ✨
	</p>
	
        <div class="footer-links">
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
        </div>

        <div class="social-text">
            <a href="#">💌 Instagram</a>
            <a href="#">🎀 Facebook</a>
            <a href="#">🌷 Pinterest</a>
        </div>

    <p class="copy">© <?php echo date("Y"); ?> Petals & Paper | Made with 💖</p>
    </div>
</footer>

<!-- JS-Slideshow -->
<script>
let slides = document.querySelectorAll(".slideshow img");
let index = 0;

function showSlide() {
    slides.forEach((slide, i) => {
        slide.classList.remove("active");
        if (i === index) slide.classList.add("active");
    });
    index = (index + 1) % slides.length;
}

setInterval(showSlide, 4000);

</script>
</body>
</html>
