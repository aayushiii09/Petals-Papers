-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2025 at 11:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petals_paper`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_ids` varchar(255) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_ids`, `total_amount`, `order_date`) VALUES
(1, 1, '2', 1299.00, '2025-09-01 07:40:34'),
(2, 1, '3', 199.00, '2025-09-01 07:48:28'),
(3, 1, '1', 799.00, '2025-09-01 07:48:52'),
(4, 1, '3:1', 199.00, '2025-09-01 07:55:37'),
(5, 1, '31', 1239.00, '2025-09-01 08:00:30'),
(6, 1, '5,7,18', 2148.00, '2025-09-01 08:00:50');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`) VALUES
(1, 'Ocean Breeze Candle & Diffuser Set', 799.00, 'p3.jpg'),
(2, 'Sparkling Silver Jewelry Set', 1299.00, 'p6.jpg'),
(3, 'Elegant Wedding Invitation Card', 199.00, 'p7.jpg'),
(4, 'Rose Luxe Perfume', 699.00, 'p9.jpg'),
(5, 'Mini Dessert Soaps Gift Pack', 299.00, 'p24.jpg'),
(6, 'Crystal Top Gel Pens (Set of 3)', 149.00, 'p20.jpg'),
(7, 'Korean Sheet Mask Set (5 pcs)', 299.00, '1756535738_p16.jpg'),
(8, 'Amber Musk Perfume', 899.00, '1756544366_p11.jpg'),
(9, 'Pink Blossom Bouquet (Artificial Flowers)', 699.00, '1756544662_p4.jpg'),
(11, 'Cute Macaron Style Calculator', 499.00, '1756552990_p23.jpg'),
(12, 'Premium Dry Fruit & Snacks Hamper', 1499.00, '1756640545_p13.jpg'),
(13, 'Towels set plain white', 149.00, '1756640609_p17.jpg'),
(14, 'Hydrating Glow Face Serum', 749.00, '1756640681_p15.jpg'),
(16, 'Skincare Essentials Kit (Lotion + Scrub + Cream)', 1499.00, '1756641729_p35.jpg'),
(17, 'Citrus Glow Body Scrub', 1299.00, '1756642137_p31.jpg'),
(18, 'Floral Infused Handmade Soap Set(set of 9)', 1550.00, '1756642300_p26.jpg'),
(19, 'Aesthetic Galaxy Letter Pad', 400.00, '1756642383_p30.jpg'),
(20, 'Pink Bow Gift Box (Empty for DIY Hampers)', 249.00, '1756642515_p33.jpg'),
(21, 'Miss Joy Eau de Parfum', 1799.00, '1756642609_p34.jpg'),
(22, 'Minimalist Gold Heart Necklace', 499.00, '1756642690_p32.jpg'),
(23, 'Aesthetic Spiral Notebook (Macaron Design)', 250.00, '1756643031_p22.jpg'),
(24, 'Cozy Brew Ceramic Tea Set (Mugs + Cups)', 1300.00, '1756643212_p12.jpg'),
(25, 'Pastel Aura Highlighters (Set of 6)', 249.00, '1756643293_p21.jpg'),
(26, 'Elegant Note Thank You Cards', 479.00, '1756643362_p27.jpg'),
(27, 'Rose Quartz Glow Eye Mask', 449.00, '1756643397_p29.jpg'),
(30, 'Blossom Charm Paper Clips (Set of 4)', 149.00, '1756645804_p25.jpg'),
(31, 'Rose Velvet Exfoliating Scrub', 1239.00, '1756645960_p18.jpg'),
(32, 'Pastel Dreams Stationery Kit', 899.00, '1756646074_p2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('user','admin') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`) VALUES
(1, 1, 3),
(2, 1, 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
