<?php
session_start();
if(isset($_POST['send_message'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    // simple PHP mail,store in DB can be added later
    $success = "Thank you, $name! Your message has been received.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Contact Us - Petals & Paper</title>
<link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Playfair+Display:wght@400;700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
<style>
body { font-family:'Lato', sans-serif; background:#fff0f5; margin:0; color:#333; }
header {
    background: linear-gradient(135deg, #ffb6c1, #ff69b4);
    padding:20px 50px; display:flex; justify-content:space-between; align-items:center;
    position:sticky; top:0; z-index:1000; box-shadow:0 5px 15px rgba(0,0,0,0.1);
}
header h1 { font-family:'Pacifico', cursive; font-size:2.5em; color:white; }
nav a { color:white; text-decoration:none; margin-left:25px; font-weight:bold; transition:0.3s; }
nav a:hover { text-decoration:underline; }

.section { padding:80px 50px; text-align:center; }
.section h2 { font-family:'Playfair Display', serif; font-size:2.5em; color:#ff1493; margin-bottom:20px; }
.section p { font-size:1.2em; color:#333; margin-bottom:40px; }

form {
    max-width:600px; margin:0 auto; display:flex; flex-direction:column; gap:20px;
}
input, textarea {
    padding:12px; border-radius:12px; border:1px solid #ffb6c1; font-size:1em;
}
textarea { resize:none; height:150px; }
button {
    padding:15px; background:linear-gradient(135deg,#ff69b4,#ff1493);
    color:white; border:none; border-radius:12px; font-size:1.1em; cursor:pointer; transition:0.3s;
}
button:hover { background:linear-gradient(135deg,#ff1493,#ff69b4); transform:scale(1.05); }

.success { color:#ff1493; font-weight:bold; margin-bottom:20px; }

footer { text-align:center; padding:25px; background:#ffb6c1; color:white; font-weight:bold; }
</style>
</head>
<body>

<header>
    <h1>🌸 Petals & Paper</h1>
    <nav>
        <a href="index.php">Home</a>
        <a href="user/user_dashboard.php">Shop</a>
        <a href="about.php">About</a>
        <?php if(isset($_SESSION['id']) && $_SESSION['role']=="user"){ ?>
            <a href="logout.php">Logout</a>
        <?php } else { ?>
            <a href="login.php">Login</a>
            <a href="registration.php">Register</a>
        <?php } ?>
    </nav>
</header>

<section class="section">
    <h2>Contact Us</h2>
    <p>We would love to hear from you! Please fill out the form below and we will get back to you shortly. 🌸</p>
    <?php if(isset($success)) echo '<p class="success">'.$success.'</p>'; ?>
    <form method="post" action="">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="email" name="email" placeholder="Your Email" required>
        <textarea name="message" placeholder="Your Message" required></textarea>
        <button type="submit" name="send_message">Send Message</button>
    </form>
</section>

<footer>
    &copy; <?php echo date("Y"); ?> Petals & Paper | All Rights Reserved
</footer>

</body>
</html>