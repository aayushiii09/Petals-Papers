<?php
session_start();
include("../connection.php");

// Check user login
if(!isset($_SESSION['id']) || $_SESSION['role'] != "user"){
    header("Location: ../login.php");
    exit;
}

// Handle Add to Cart
if(isset($_POST['add_to_cart'])){
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    $user_id = $_SESSION['id'];

    $check = $conn->query("SELECT * FROM cart WHERE user_id=$user_id AND product_id=$product_id");
    if($check->num_rows > 0){
        $conn->query("UPDATE cart SET quantity = quantity + $quantity WHERE user_id=$user_id AND product_id=$product_id");
    } else {
        $conn->query("INSERT INTO cart (user_id, product_id, quantity) VALUES ($user_id, $product_id, $quantity)");
    }
    header("Location: user_dashboard.php");
    exit;
}

// Handle Wishlist
if(isset($_POST['add_wishlist'])){
    $product_id = intval($_POST['product_id']);
    $user_id = $_SESSION['id'];

    $check = $conn->query("SELECT * FROM wishlist WHERE user_id=$user_id AND product_id=$product_id");
    if($check->num_rows == 0){
        $conn->query("INSERT INTO wishlist (user_id, product_id) VALUES ($user_id, $product_id)");
    }
    header("Location: user_dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Petals & Paper - Shop</title>
<link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<style>
/* Reset & fonts */
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: 'Roboto', sans-serif; background:#fff0f5; color:#333; }

/* Header */
header { background: linear-gradient(135deg, #ffb6c1, #ffc0cb); padding:25px; text-align:center; color:white; position:sticky; top:0; z-index:1000; box-shadow:0 5px 15px rgba(0,0,0,0.1);}
header h1 { font-family:'Pacifico', cursive; font-size:2.8em; margin-bottom:5px; }
header p { font-size:1em; }
header a { color:white; text-decoration:none; margin-left:15px; font-weight:bold; transition:0.3s; }
header a:hover { text-decoration:underline; }

/* Products Container - Grid layout for 5 per row */
.products-container {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 25px;
    padding: 30px;
    max-height: calc(100vh - 120px);
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #ffb6c1 #ffe4e1;
}
.products-container::-webkit-scrollbar { width: 8px; }
.products-container::-webkit-scrollbar-thumb { background: #ffb6c1; border-radius: 10px; }
.products-container::-webkit-scrollbar-track { background: #ffe4e1; }

/* Product Card */
.card { background:#fff; border-radius:20px; width:220px; text-align:center; padding:20px; box-shadow:0 10px 20px rgba(255,182,193,0.3); transition:0.3s; display:flex; flex-direction:column; align-items:center; }
.card:hover { transform:translateY(-10px) scale(1.05); box-shadow:0 15px 25px rgba(255,182,193,0.5); }
.card img { width:100%; height:200px; border-radius:15px; object-fit:cover; margin-bottom:15px; }
.card h2 { color:#ff69b4; font-size:1.2em; margin-bottom:5px; font-family:'Pacifico', cursive; }
.card p { font-weight:bold; color:#ff1493; margin-bottom:10px; font-size:1.1em; }
.card form { display:flex; flex-direction:column; align-items:center; width:100%; }
.card input[type="number"] { width:60px; padding:5px; margin-bottom:10px; text-align:center; border:1px solid #ffb6c1; border-radius:10px; }
.card button { padding:10px 20px; margin-top:5px; background:linear-gradient(135deg, #ff69b4, #ff1493); color:white; border:none; border-radius:12px; cursor:pointer; font-weight:bold; transition:0.3s; width:100%; }
.card button:hover { background:linear-gradient(135deg, #ff1493, #ff69b4); transform:scale(1.05); }

/* Responsive for smaller screens */
@media (max-width:1300px){ .products-container { grid-template-columns: repeat(4, 1fr); } }
@media (max-width:1000px){ .products-container { grid-template-columns: repeat(3, 1fr); } }
@media (max-width:700px){ .products-container { grid-template-columns: repeat(2, 1fr); } }
@media (max-width:500px){ .products-container { grid-template-columns: 1fr; } }
</style>
</head>
<body>

<header>
    <h1>🌸 Petals & Paper</h1>
    <p>Welcome, <?php echo $_SESSION['name']; ?> | 
    <a href="../logout.php">Logout</a> | 
    <a href="viewcart.php">🛒 View Cart</a> | 
    <a href="wishlist.php">🌸 View Wishlist</a></p>
</header>

<div class="products-container">
<?php
$sql = "SELECT id, name, price, image FROM products";
$result = $conn->query($sql);

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        $img = !empty($row['image']) ? $row['image'] : 'default.jpg';
        echo '<div class="card">';
        echo '<img src="../images/'.$img.'" alt="product">';
        echo '<h2>'.$row['name'].'</h2>';
        echo '<p>₹'.$row['price'].'</p>';
        echo '<form method="post">';
        echo '<input type="hidden" name="product_id" value="'.$row['id'].'">';
        echo '<input type="number" name="quantity" value="1" min="1">';
        echo '<button type="submit" name="add_to_cart">🛒 Add to Cart</button>';
        echo '<button type="submit" name="add_wishlist">🌸 Add to Wishlist</button>';
        echo '</form>';
        echo '</div>';
    }
}else{
    echo "<p style='text-align:center; width:100%; color:#ff69b4; font-size:1.2em;'>No products available!</p>";
}
?>
</div>

</body>
</html>
