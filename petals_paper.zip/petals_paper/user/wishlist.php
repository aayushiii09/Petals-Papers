<?php
session_start();
include("../connection.php");

if(!isset($_SESSION['id']) || $_SESSION['role'] != "user"){
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['id'];
$sql = "SELECT wishlist.id as wid, products.name, products.price, products.image 
        FROM wishlist 
        JOIN products ON wishlist.product_id = products.id 
        WHERE wishlist.user_id=$user_id";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Wishlist - Petals & Paper</title>
<style>
body { font-family:Arial, sans-serif; background:#fff0f5; margin:0; padding:0; }
header { background:linear-gradient(135deg,#ffb6c1,#ffc0cb); padding:20px; text-align:center; color:white; }
header a { color:white; margin-left:10px; font-weight:bold; text-decoration:none; }
header a:hover { text-decoration:underline; }

.wishlist-container { max-width:900px; margin:40px auto; background:#fff; padding:30px; border-radius:20px; box-shadow:0 10px 20px rgba(255,182,193,0.3); }
.wishlist-container h2 { text-align:center; color:#ff69b4; margin-bottom:20px; }
table { width:100%; border-collapse:collapse; }
th,td { padding:12px; text-align:center; border-bottom:1px solid #ffb6c1; }
th { background:#ffb6c1; color:white; }
img { width:80px; height:80px; object-fit:cover; border-radius:10px; }
</style>
</head>
<body>
<header>
    <h1>🌸 Petals & Paper</h1>
    <p>Welcome, <?php echo $_SESSION['name']; ?> |
    <a href="user_dashboard.php">🏠 Shop</a> |
    <a href="../logout.php">Logout</a></p>
</header>

<div class="wishlist-container">
<h2>My Wishlist</h2>
<?php
if($result->num_rows > 0){
    echo "<table>";
    echo "<tr><th>Image</th><th>Product</th><th>Price</th></tr>";
    while($row = $result->fetch_assoc()){
        $img = !empty($row['image']) ? $row['image'] : 'default.jpg';
        echo "<tr>";
        echo "<td><img src='../images/$img' alt='product'></td>";
        echo "<td>".$row['name']."</td>";
        echo "<td>₹".$row['price']."</td>";
        echo "</tr>";
    }
    echo "</table>";
}else{
    echo "<p style='text-align:center; color:#ff69b4;'>No items in wishlist!</p>";
}
?>
</div>
</body>
</html>
