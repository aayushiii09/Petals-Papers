<?php
session_start();
include("../connection.php");

// Check user login
if(!isset($_SESSION['id']) || $_SESSION['role'] != "user"){
    header("Location: ../login.php");
    exit;
}

// Handle quantity update
if(isset($_POST['update_cart'])){
    $cart_id = intval($_POST['cart_id']);
    $quantity = intval($_POST['quantity']);
    if($quantity > 0){
        $conn->query("UPDATE cart SET quantity=$quantity WHERE id=$cart_id");
    }
    header("Location: viewcart.php");
    exit;
}

// Handle remove item
if(isset($_GET['remove'])){
    $cart_id = intval($_GET['remove']);
    $conn->query("DELETE FROM cart WHERE id=$cart_id");
    header("Location: viewcart.php");
    exit;
}

// Handle place order
if(isset($_POST['place_order'])){
    $user_id = $_SESSION['id'];
    $cart_items = $conn->query("SELECT product_id, quantity FROM cart WHERE user_id=$user_id");

    if($cart_items->num_rows > 0){
        $product_ids = [];
        $total = 0;

        while($row = $cart_items->fetch_assoc()){
            $product_ids[] = $row['product_id'];

            // get product price
            $p = $conn->query("SELECT price FROM products WHERE id=".$row['product_id'])->fetch_assoc();
            $total += $p['price'] * $row['quantity'];
        }

        $product_ids_str = implode(",", $product_ids);

        // Insert into orders table
        $conn->query("INSERT INTO orders (user_id, product_ids, total_amount, order_date) 
                      VALUES ($user_id, '$product_ids_str', $total, NOW())");

        // Clear cart
        $conn->query("DELETE FROM cart WHERE user_id=$user_id");

        $success_message = "🎉 Order placed successfully!";
    }
}

$user_id = $_SESSION['id'];
$sql = "SELECT cart.id as cart_id, products.name, products.price, products.image, cart.quantity 
        FROM cart 
        JOIN products ON cart.product_id = products.id 
        WHERE cart.user_id=$user_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Petals & Paper - Your Cart</title>
<link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<style>
body { font-family: 'Roboto', sans-serif; background:#fff0f5; color:#333; margin:0; padding:0; }
header { background: linear-gradient(135deg, #ffb6c1, #ffc0cb); padding:25px; text-align:center; color:white; position:sticky; top:0; z-index:1000; box-shadow:0 5px 15px rgba(0,0,0,0.1);}
header h1 { font-family:'Pacifico', cursive; font-size:2.8em; margin-bottom:5px; }
header a { color:white; text-decoration:none; margin-left:15px; font-weight:bold; transition:0.3s; }
header a:hover { text-decoration:underline; }

.cart-container { max-width:900px; margin:40px auto; background:#fff; padding:30px; border-radius:20px; box-shadow:0 10px 20px rgba(255,182,193,0.3); }
.cart-container h2 { text-align:center; font-family:'Pacifico', cursive; color:#ff69b4; margin-bottom:30px; }
.cart-table { width:100%; border-collapse:collapse; }
.cart-table th, .cart-table td { padding:15px; text-align:center; border-bottom:1px solid #ffc0cb; }
.cart-table th { background:#ffb6c1; color:white; font-weight:bold; }
.cart-table img { width:80px; height:80px; object-fit:cover; border-radius:10px; }
.cart-table input[type="number"] { width:60px; padding:5px; text-align:center; border:1px solid #ffb6c1; border-radius:10px; }
.cart-table button { padding:8px 15px; background:linear-gradient(135deg,#ff69b4,#ff1493); color:white; border:none; border-radius:12px; cursor:pointer; transition:0.3s; }
.cart-table button:hover { background:linear-gradient(135deg,#ff1493,#ff69b4); transform:scale(1.05); }
.total { text-align:right; font-weight:bold; font-size:1.2em; margin-top:20px; color:#ff1493; }
.empty-cart { text-align:center; color:#ff1493; font-size:1.2em; padding:20px; }
.success { text-align:center; color:green; font-weight:bold; margin-bottom:20px; }
</style>
</head>
<body>

<header>
    <h1>🌸 Petals & Paper</h1>
    <p>Welcome, <?php echo $_SESSION['name']; ?> | 
    <a href="user_dashboard.php">🏠 Shop</a> | 
    <a href="../logout.php">Logout</a></p>
</header>

<div class="cart-container">
    <h2>Your Cart</h2>

    <?php if(isset($success_message)) echo "<p class='success'>$success_message</p>"; ?>

    <?php
    if($result->num_rows > 0){
        $total = 0;
        echo '<form method="post">';
        echo '<table class="cart-table">';
        echo '<tr><th>Image</th><th>Product</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th>Action</th></tr>';
        while($row = $result->fetch_assoc()){
            $subtotal = $row['price'] * $row['quantity'];
            $total += $subtotal;
            $img = !empty($row['image']) ? $row['image'] : 'default.jpg';
            echo '<tr>';
            echo '<td><img src="../images/'.$img.'" alt="product"></td>';
            echo '<td>'.$row['name'].'</td>';
            echo '<td>₹'.$row['price'].'</td>';
            echo '<td>
                    <form method="post" style="display:inline-block;">
                        <input type="hidden" name="cart_id" value="'.$row['cart_id'].'">
                        <input type="number" name="quantity" value="'.$row['quantity'].'" min="1">
                        <button type="submit" name="update_cart">Update</button>
                    </form>
                  </td>';
            echo '<td>₹'.$subtotal.'</td>';
            echo '<td><a href="viewcart.php?remove='.$row['cart_id'].'" style="color:#ff1493; font-weight:bold;">Remove</a></td>';
            echo '</tr>';
        }
        echo '</table>';
        echo '<p class="total">Total: ₹'.$total.'</p>';
        echo '<div style="text-align:center; margin-top:20px;">
                <button type="submit" name="place_order">✅ Place Order</button>
              </div>';
        echo '</form>';
    } else {
        echo '<p class="empty-cart">Your cart is empty!</p>';
    }
    ?>
</div>

</body>
</html>
