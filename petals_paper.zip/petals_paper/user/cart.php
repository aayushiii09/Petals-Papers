<?php
session_start();
include("../connection.php");

// Check if user is logged in
if(!isset($_SESSION['id']) || $_SESSION['role'] != "user"){
    header("Location: ../login.php");
    exit;
}

if(isset($_GET['id'])){
    $productId = intval($_GET['id']);

    // Fetch product info
    $stmt = $conn->prepare("SELECT id, name, price, image FROM products WHERE id=?");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows > 0){
        $product = $result->fetch_assoc();
        
        // Add to session cart
        if(!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
        
        if(isset($_SESSION['cart'][$productId])){
            $_SESSION['cart'][$productId]['quantity'] += 1;
        } else {
            $_SESSION['cart'][$productId] = [
                "name" => $product['name'],
                "price" => $product['price'],
                "image" => $product['image'],
                "quantity" => 1
            ];
        }

        header("Location: viewcart.php");
        exit;
    } else {
        echo "Product not found!";
    }
} else {
    header("Location: user_dashboard.php");
    exit;
}
?>
